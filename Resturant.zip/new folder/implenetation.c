#include "header.h"
/*A function that gets a file and an empty meal list and transfer all the data from the file to 
the list.*/
void CreateProducts(meal** head, meal** tail, FILE* fp)
{
	meal* temp, * beforelast = NULL;
	char name[50];
	temp = (meal*)malloc(sizeof(meal));
	if (temp == NULL)
	{
		Error_Msg("Error head allocation\n");
	}
	if (*tail == NULL)
	{
		*tail = temp;
		*head = temp;
		(*tail)->next = NULL;
	}
	while (fscanf(fp, "%s %d %d", name, &temp->quan, &temp->price) != EOF)
	{
		if (temp->quan > 0 && temp->price > 0)
		{
			temp->name = (char*)malloc((strlen(name) + 1) * sizeof(char));
			if (temp->name == NULL)
			{
				FreeMem(head);
				free(temp);
				Error_Msg("Error name allocation\n");
			}
			strcpy(temp->name, name);
			if ((CheckName(*head, name)) == 0)
			{
				beforelast = temp;
				temp = (meal*)malloc(sizeof(meal));
				temp->next = NULL;
				(*tail)->next = temp;
				*tail = temp;
			}
			else
			{
				printf("Error - meal already exist\n");
			}
		}
		else
		{
			printf("Error - quantity or price must be bigger than 0\n");
		}
	}
	(*tail) = beforelast;
	(*tail)->next = NULL;
}
/*A function that gets a string and prints it and shut down the program.*/
void Error_Msg(char* str)
{
	printf("%s", str);
	exit(1);
}
/*A function that gets a list and free all the memmory from the list.*/
void FreeMem(meal* head)
{
	meal* temp;
	while (head != NULL)
	{
		free(head->name);
		temp = head;
		head = head->next;
		free(temp);
	}
}
/*A function that gets a list and a name and checks if the name of the meal is within the
meal list, returns 1 if found, 0 if not.*/
int CheckName(meal* head, char* name)
{
	int cnt = 0;
	while (head != NULL)
	{
		if (strcmp(head->name, name) == 0)
		{
			cnt++;
			if (cnt > 1)
			{
				return 1;
			}
		}
		head = head->next;
	}
	return 0;
}
/*A function that gets a list and a name and checks if the name of the meal is within the
meal list, returns the meal address if found, NULL if not.*/
meal* CheckNameIdx(meal* head, char* name)
{
	while (head != NULL)
	{
		if (strcmp(head->name, name) == 0)
		{
			return head;
		}
		head = head->next;
	}
	return NULL;
}
/*A function that gets a list, name and an amount to add to the quantity, it uses CheckNameIdx
function in order to track the wanted meal, and then add to the quantity.*/
void AddItems(meal** head, char* name, int add)
{
	meal* temp;
	if (add < 0)
	{
		printf("Error - quantity must be bigger than 0\n");
	}
	else
	{
		temp = *head;
		temp = CheckNameIdx(temp, name);
		if (temp != NULL)					//Found meal
		{
			(temp)->quan += add;
			printf("%d %s were added to the kitchen\n", add, name);
		}
		else
		{
			printf("Error - meal does not exist\n");
		}
	}
}
/*A function that gets a list of tables, desired table number, desired meal name and a list 
of meals, the function uses CheckNameIdx function in order to track the exact meal and
insert to the desired table the amount of meals he wanted of that meal name, plus the function
reduce the amount of meals of that kind by the amount of meals ordered.*/
void OrderItem(table** arrtbl, int idx, char* mealname, int quan, meal* head)
{
	int flag = 1;
	meal* temp, * temp2;
	if (idx < N + 1)
	{
		temp = CheckNameIdx(head, mealname);
		if (temp != NULL)
		{
			if (temp->quan > 0)
			{
				temp2 = (meal*)malloc(sizeof(meal));
				if (temp2 == NULL)
				{
					FreeMem((*arrtbl)[idx].tblhead);
					free(*arrtbl);
					FreeMem(head);
					Error_Msg("Error allocation\n");
				}
				temp2->next = (*arrtbl)[idx].tblhead;
				(*arrtbl)[idx].tblhead = temp2;
				temp2->name = (char*)malloc((strlen(mealname) + 1) * sizeof(char));
				strcpy(temp2->name, mealname);
				temp2->quan = quan;
				temp2->price = temp->price;
				temp->quan -= quan;
			}
			else
			{
				printf("There is no quantity left\n");
				flag = 0;
			}
		}
		else
		{
			printf("We don't have %s, sorry!\n", mealname);
			flag = 0;
		}
	}
	else
	{
		printf("There is no such table\n");
		flag = 0;
	}
	if (flag == 1)
	{
		printf("%d %s were added to the table number %d\n", quan, mealname, idx);
	}
}
/*A function that gets table number and a list of tables and removes the last meal ordered
in the desired table.*/
void RemoveItem(int idx, table** arrtbl)
{
	meal* temp;
	if ((*arrtbl)[idx].tblhead == NULL)
	{
		printf("There are no orders in the table number %d\n", idx);
	}
	else
	{
		free((*arrtbl)[idx].tblhead->name);
		temp = (*arrtbl)[idx].tblhead;
		(*arrtbl)[idx].tblhead = (*arrtbl)[idx].tblhead->next;
		free(temp);
	}
}
/*A function that gets table number and a list of tables and, it calculated the sum+tip
and than prints the bill, after that it removes the table(free all its meals)*/
void RemoveTable(int idx, table** arrtbl)
{
	meal* temp;
	int sum = 0, M = 0;
	float tip;
	while ((*arrtbl)[idx].tblhead != NULL)
	{
		printf("%d %s. ", (*arrtbl)[idx].tblhead->quan, (*arrtbl)[idx].tblhead->name);
		M = ((*arrtbl)[idx].tblhead->price) * ((*arrtbl)[idx].tblhead->quan);
		sum += M;
		temp = (*arrtbl)[idx].tblhead;
		(*arrtbl)[idx].tblhead = (*arrtbl)[idx].tblhead->next;
		free(temp->name);
		free(temp);
	}
	if (sum != 0)
	{
		tip = (sum) * 15 / 100.0;
		printf("%d nis+%g nis for tips, please!\n", sum, tip);
	}
	else
	{
		printf("The table number %d is not ordered yet\n", idx);
	}
}
