#include "header.h"
/*Main function creates a list of meals by a file openned and creates an array of tables,
it uses Instruction file and gets the orders by that file, it opens menu which seperated
into 5 options. The first option is CreateProducts func, the second one is AddItems func,
the third one is OrderItem func, the fourth is RemoveItem func and the last is RemoveTable func.
The fucntion will run aslong as the Instruction file does not end, at the end, it will free all the 
memmory that was beeing used in the program.*/
int main()
{
	meal* head = NULL, * temp, * tail = NULL;
	table* arrtable;
	FILE* fpi, * fpm;
	int option, addquan, tblnum;
	char name[50];
	int i;
	arrtable = (table*)malloc((N + 1) * sizeof(table));
	for (i = 0; i < N + 1; i++)
	{
		arrtable[i].tblhead = NULL;
	}

	if (arrtable == NULL)
	{
		Error_Msg("Error allocation\n");
	}

	fpi = fopen("Instructions.txt", "r");
	if (fpi == NULL)
	{
		Error_Msg("Error openning file\n");
	}
	fscanf(fpi, "%d", &option);
	if (option != 1)
	{
		Error_Msg("First option must be 1\n");
	}
	else
	{
		fpm = fopen("Manot.txt", "r");
		if (fpm == NULL)
		{
			Error_Msg("Error openning file\n");
		}
		CreateProducts(&head, &tail, fpm);
		fclose(fpm);
		printf("The kitchen was created\n");
	}

	while (fscanf(fpi, "%d", &option) != EOF)
	{
		switch (option)
		{
		case 2:
			fscanf(fpi, "%s %d", name, &addquan);
			AddItems(&head, name, addquan);
			break;
		case 3:
			fscanf(fpi, "%d %s %d", &tblnum, name, &addquan);
			OrderItem(&arrtable, tblnum, name, addquan, head);
			break;
		case 4:
			fscanf(fpi, "%d", &tblnum);
			printf("%d %s was returned to the kitchen from table number %d\n", arrtable[tblnum].tblhead->quan, arrtable[tblnum].tblhead->name, tblnum);
			RemoveItem(tblnum, &arrtable);
			break;
		case 5:
			fscanf(fpi, "%d", &tblnum);
			RemoveTable(tblnum, &arrtable);
			break;
		default:
			break;
		}
	}
	FreeMem(head);
	for (i = 0; i < N + 1; i++)
	{
		FreeMem(arrtable[i].tblhead);
	}
	free(arrtable);
	return 0;
}
