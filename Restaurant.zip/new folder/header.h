#ifndef _implenetation
#define _implenetation
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
#define N 6

typedef struct meal
{
	char* name;
	int price, quan;
	struct meal* next;
}meal;

typedef struct table
{
	int tblnum;
	meal* tblhead;
}table;

void CreateProducts(meal** head, meal** tail, FILE* fp);
void FreeMem(meal* head);
int CheckName(meal* head, char* name);
void AddItems(meal** head, char* name, int add);
void Error_Msg(char* str);
meal* CheckNameIdx(meal* head, char* name);
void OrderItem(table** arrtbl, int idx, char* mealname, int quan, meal* head);
void RemoveItem(int idx, table** arrtbl);
void RemoveTable(int idx, table** arrtbl);
#endif
